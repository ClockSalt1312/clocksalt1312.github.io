/* ============================================================
 * 盐津虾 VIP · 卡密激活模块（vip.js）
 * 纯前端方案：代码里只存卡密的加盐 SHA-256 哈希，不存明文。
 * 卡密哈希 -> 有效天数。新增卡密：把哈希加到下表即可。
 * ============================================================ */
const VIP_CODES = {
  '0e2c245a43bf70cceb02a0905451eecb4f2f73e4a4c4c5b38fbefae6d5c04c73': 30,  // 月卡①
  'f12a598b44951230df025fe846f58c7d36722274ae6588221f011187f0b9c476': 30,  // 月卡②
  '24a46a2f558f4fce140dbb58c0f8a3fdc0e6f6b9c3c7f766233e52e3c5465582': 90,  // 季卡①
  'e427046b03c50b053dd4966ae6b7c5af6cd366961ab6c811067273d2df78454e': 90,  // 季卡②
  '283a4eb195ca2d1d03a1a1c30cdeae2e356a44b683f723453b2c8152a182438e': 365, // 年卡①
};

const VIP_KEY = 'sos_vip_v1';
const VIP_SALT = 'YJX::';

/* 1.0 正式版：卡密激活通道正式开放 */
function vipActivationOpen(){
  return true;
}

function vipNormalize(code){
  return String(code || '').trim().toUpperCase().replace(/\s+/g, '');
}

async function vipSha256(text){
  if(!window.crypto || !crypto.subtle) throw new Error('no-crypto');
  const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(text));
  return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2, '0')).join('');
}

/* 查询当前 VIP 状态：{ expire } 或 null；过期记录自动清除 */
function getVip(){
  try{
    const v = JSON.parse(localStorage.getItem(VIP_KEY) || 'null');
    if(v && typeof v.expire === 'number'){
      if(v.expire > Date.now()) return v;
      localStorage.removeItem(VIP_KEY); /* 到期自动取消 */
    }
  }catch(e){}
  return null;
}

function vipExpireText(){
  const v = getVip();
  if(!v) return '';
  const d = new Date(v.expire);
  return d.getFullYear() + '/' + String(d.getMonth() + 1).padStart(2, '0') + '/' + String(d.getDate()).padStart(2, '0');
}

/* 激活卡密。返回 { ok, days, expire, reason } */
async function redeemVipCode(code){
  const norm = vipNormalize(code);
  if(!norm) return { ok:false, reason:'empty' };
  let hash;
  try{
    hash = await vipSha256(VIP_SALT + norm);
  }catch(e){
    return { ok:false, reason:'crypto' };
  }
  const days = VIP_CODES[hash];
  if(!days) return { ok:false, reason:'invalid' };
  const now = Date.now();
  /* 已是 VIP 则叠加续费 */
  let expire = now + days * 864e5;
  const cur = getVip();
  if(cur) expire = cur.expire + days * 864e5;
  try{ localStorage.setItem(VIP_KEY, JSON.stringify({ h: hash, expire: expire })); }catch(e){}
  return { ok:true, days:days, expire:expire };
}
